# Develop with the workbench

The workbench is a local browser preview for package components. It uses local examples, so you can build and click through a component without starting Twig.com or signing in to PostHog.

## Preserve the approved design

Every existing and new example must use the [approved visual system](design-system.md), shared components, CSS classes, and tokens. Workbench-specific layout is for presenting fixtures, not an alternative product design. A new feature does not authorize a new visual pattern. Any explicitly approved system change must update the shared implementation, examples, and both design guides together.

Review the real Twig pages too, including login, all account sections, stay details, empty/populated states, and fallbacks. For broad styling changes, use Twig.com’s full route/state inventory at desktop, 390px, and 320px; a correct workbench preview alone is insufficient.

## Start it

From this repo:

```sh
npm ci
npm run workbench
```

Open the URL printed in the terminal (normally `http://127.0.0.1:5173`). Choose **Twig views** or a lab from the left menu. Changes in `src/`, `workbench/App.tsx`, and the CSS refresh the page while the server runs. Stop it with `Ctrl+C`.

## Add or change a component

1. Build the reusable UI in `src/`. Keep site routes, navigation, and real PostHog event calls in Twig.com.
2. If it is a new public component, add its import path to `package.json` → `exports` and describe it in [components.md](components.md). Use a `.js` extension for imports between TypeScript source files, as the existing components do.
3. Add a preview to `workbench/App.tsx`. Import directly from `../src/` so edits appear immediately. Add it to an existing view, or add a menu entry for a distinct component.
4. Pass example props and local callbacks. For a clickable component, let the preview own its state with React's `useState` or the package reducer. The **Events and properties** preview shows the pattern: click a Twig filter, update local state, then inspect the event.
5. Check the states someone will actually see: initial, clicked or changed, success or error, narrow width, and keyboard focus. For a lab, click through the whole lesson, not just its first screen.

The workbench's AI and booking actions use fixtures. The replay tab previews lesson states with a fixture; test actual recording and any site routing in Twig.com. Never put credentials or real visitor data in a fixture.

## Before review

```sh
npm test
npm run workbench:build
npm run gallery
npm pack --dry-run
```

`npm test` checks the package behavior. `workbench:build` checks that previews type-check and bundle. `gallery` produces static snapshots for visual review. `npm pack --dry-run` shows what would ship; the workbench itself is development-only and is excluded from the npm package.

When the component is used on Twig.com, check it there too. If PostHog 101 uses it, also check the guide's Shadow DOM styling and keep its PostHog inspector outside that boundary. See [integration and updates](integration.md) for how changes reach each site.

## Review the Events and properties lab

Choose **Events and properties**, then **Web app** or **Agent**. Click a destination filter above the lesson. Work through naming the event, adding a destination property, adding number and boolean properties, and comparing selections. Apply each code change before clicking another filter. The destination-property step needs two different destinations. **All locations** clears the filter and does not count as a destination from that step onward.

In the agent path, send the prepared message and wait for the response. Expand the tool row to inspect the simulated request and result summary. Code edits belong to the simulated agent. Event reads use the real PostHog MCP tool names and input shapes, but execute locally without a PostHog connection.

Check both paths, the experience toggle, Previous, Reset, and both copy icons on the completion page. Check desktop and mobile layouts. With the operating system's reduced-motion setting enabled, responses should appear immediately.

## Review the AIO trip planner

Choose **Trip planner** and start the lab. Follow the chat through the city request. Run the capacity evaluation before inspecting the trace, apply the guest filter, retry the request, then run the same evaluation again. The first check fails and the second passes. Check Previous and Reset at both evaluation stages, and verify chat prompts stay locked until their lesson step.

## Review mobile account navigation

In the account preview, log in and check Profile, Saved stays, Booked stays and Account settings at 390px and 320px. Content appears immediately; open the header avatar to navigate. Check closed/open states, Escape returning focus, outside-click dismissal and Log out. Desktop keeps the sidebar. Add saved/booking fixtures to check populated states as well as empty states.

Check plus/minus states in Product menu and the later lab steps, including nested disclosures. In Events and properties, tab to a recorded event: the blue keyboard outline spans the event and time cells.

Check Events and properties in both Web app and Agent: the first filter action is a single instruction, and configuration plus distinct filter selections use one progressive checklist. Repeated clicks on the same setting must not complete the different-setting item. Check later setup, retry and mobile-return directions across every lab.


The Playground controls preview exercises connected choices, highlighted code, transient copy feedback, Wizard commands and the editable local MCP composer. Review it at 1440, 390 and 320px, including keyboard focus, copy denial and reduced motion. The Events and properties preview exercises all five steps in both experiences, including switching from web evidence to an unsent agent request.

The Controls preview includes shared AI trace, captured Input/Output chat, failed/passed evaluation surfaces, and the four brand statuses. The Trip planner and Inspector previews exercise the same primitives with recorded evidence.

Finalized controls are available under Playground controls: Ready/Playing/Ended playback, real seek callbacks, active recording/Start recording, Active/Resolved statuses, code highlights, connected choices and MCP composer. The Errors preview exercises booking → exception → stack frame/source → fallback → retry → repair → verify → resolve. Review current white/blue directions before each site action and completed neutral directions afterwards. No lesson action changes the historical occurrence count unless a new exception is actually captured.


In Inspector, choose Explore on your own to see regular exploration context and the live-event play control. Simulate two interactions, select an earlier event, then use Track live events to resume following the latest event. Take a tour still uses progressive checklist directions. Check both at desktop, 390px and 320px, including keyboard focus and disabled controls.

The Offline and online evaluations preview runs the support conversation, offline coding-agent checks, online setup and three result inspections, then regression and completion. Use `?view=support` to open it.

In Support, hover or keyboard-focus the reset button. The Twig tooltip appears above the title bar. Escape dismisses it; reset still clears the conversation.
